package com.seller.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="seller")
public class Seller implements Serializable {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int sellerid;

	private String sellerUsername;

	private String sellerPassword;

	private String companyName;

	private float gstin;
	private String companyDescription;

	private String postalAddress;
	private String website;
	private String emailID;
	private long contactNo;

	public int getSellerid() {
		return sellerid;
	}
	public void setSellerid(int sellerid) {
		this.sellerid = sellerid;
	}
	public String getSellerUsername() {
		return sellerUsername;
	}
	public void setSellerUsername(String sellerUsername) {
		this.sellerUsername = sellerUsername;
	}
	public String getSellerPassword() {
		return sellerPassword;
	}
	public void setSellerPassword(String sellerPassword) {
		this.sellerPassword = sellerPassword;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public float getGSTIN() {
		return gstin;
	}
	public void setGSTIN(float gSTIN) {
		this.gstin = gstin;
	}
	public String getCompanyDescription() {
		return companyDescription;
	}
	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}
	public String getPostalAddress() {
		return postalAddress;
	}
	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public long getContactNo() {
		return contactNo;
	}
	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}

	public Seller(int sellerid, String sellerUsername, String sellerPassword, String companyName, float gSTIN,
			String companyDescription, String postalAddress, String website, String emailID, long contactNo) {
		
		this.sellerid = sellerid;
		this.sellerUsername = sellerUsername;
		this.sellerPassword = sellerPassword;
		this.companyName = companyName;
		this.gstin = gstin;
		this.companyDescription = companyDescription;
		this.postalAddress = postalAddress;
		this.website = website;
		this.emailID = emailID;
		this.contactNo = contactNo;
	}
	public Seller() {

		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Seller [sellerid=" + sellerid + ", sellerUsername=" + sellerUsername + ", sellerPassword="
				+ sellerPassword + ", companyName=" + companyName + ", gstin=" + gstin + ", companyDescription="
				+ companyDescription + ", postalAddress=" + postalAddress + ", website=" + website + ", emailID="
				+ emailID + ", contactNo=" + contactNo + "]";
	}
	
}
