package com.seller.Dao;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.seller.model.Seller;
@Repository
public interface ISellerDao extends JpaRepository<Seller, Integer> {





}



