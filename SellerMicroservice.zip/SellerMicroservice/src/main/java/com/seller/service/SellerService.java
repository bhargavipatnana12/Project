package com.seller.service;


	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

import com.seller.Dao.ISellerDao;
import com.seller.model.Seller;

	
	@Service
	public class SellerService implements ISellerService{

		
		@Autowired
		private ISellerDao sellerDao;
		
		@Override
		public List<Seller> getAllSeller() {
			return sellerDao.findAll();
		}

		@Override
		public Seller addSeller(Seller seller) {
			//System.out.println(seller);
			return sellerDao.save(seller);
		}

		

	}


		
	


