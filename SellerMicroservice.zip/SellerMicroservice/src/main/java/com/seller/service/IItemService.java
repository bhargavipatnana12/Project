package com.seller.service;

import java.util.List;

import com.seller.model.Items;

public interface IItemService {

	void deleteBySeller(Integer sId, Integer pId);

	List<Items> viewItem(Integer sellerId);

	String updateItem(int sid, int pid, Items item);
	String addItem(int sid, Items item);
	
}


