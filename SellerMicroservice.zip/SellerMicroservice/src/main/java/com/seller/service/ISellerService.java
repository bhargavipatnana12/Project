package com.seller.service;

import java.util.List;

import com.seller.model.Seller;

public interface ISellerService {

	Seller addSeller(Seller seller);

	List<Seller> getAllSeller();

}
