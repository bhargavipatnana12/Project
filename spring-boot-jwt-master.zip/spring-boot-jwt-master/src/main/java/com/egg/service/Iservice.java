package com.egg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.egg.model.BuyerDetails;
import com.egg.model.CartItems;
import com.egg.model.PurchaseHistory;
import com.egg.model.TransactionHistory;


@Service
public interface Iservice {
	//Buyers SERVICE
    List<BuyerDetails> getAll();
	BuyerDetails addBuyer(BuyerDetails buyerdetails);
	BuyerDetails getBuyer(int id);
	BuyerDetails updateBuyer(BuyerDetails buyer);
	BuyerDetails findOne(String username);
	BuyerDetails updateBuyer(BuyerDetails buyer, int id);
	//Items SERVICE
	List<CartItems> getAllItems();
	CartItems addcart(CartItems cartItems,int id);
	CartItems getItem(int id);
	CartItems updateItem(CartItems cartItems,int id);
	void  deleteItem(int id);
	void  deleteAllItem();
	
	
	//Transactions SERVICE
	List<TransactionHistory> getAllTransaction();
	TransactionHistory addcartItems(TransactionHistory transactonhistory,int id);
	TransactionHistory getTransaction(int id);
	TransactionHistory updateTransaction(TransactionHistory transactionhistory,int id);
	TransactionHistory checkOut(TransactionHistory transactonhistory,int bid);
//	TransactionHistory checkout(TransactionHistory transactionhistory,int id);
	
	
	
	//purchasehistory SERVICE
	List<PurchaseHistory> getPurchase();
	PurchaseHistory addPurchase(PurchaseHistory purchasehistory,int id,int ids);
	PurchaseHistory getpurchase(int id);
	PurchaseHistory updatePurchase(PurchaseHistory purchasehistory,int id);
	
		

	

	
}
