package com.egg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.PurchaseHistory;
import com.egg.service.Iservice;

@CrossOrigin("*")
@RestController
public class PurchaseController {
	
	@Autowired
	private Iservice service;
	
	@RequestMapping("/getAllPurchase") public List<PurchaseHistory> getPurchase() 
    {
		  return service.getPurchase(); 
    } 
	@RequestMapping(value="/Add/purchase/{ids}/{idss}",method=RequestMethod.POST)
	public PurchaseHistory add(@RequestBody PurchaseHistory purchaseHistory,@PathVariable("ids") int id,@PathVariable("idss") int ids ) 
	{
		return service.addPurchase(purchaseHistory, id,ids);
	}
	@RequestMapping(value="/getpurchase/{ids}",method=RequestMethod.GET)
	public PurchaseHistory getpurchase(@PathVariable("ids") int id) 
	{
		return service.getpurchase(id);
	}
	@RequestMapping(value="/update/purchase/{ids}",method=RequestMethod.PUT)
	public PurchaseHistory updateTransaction(@RequestBody PurchaseHistory PurchaseHistory ,@PathVariable("ids") int id) 
	{
		return service.updatePurchase(PurchaseHistory,id);
	}
	
	
}
