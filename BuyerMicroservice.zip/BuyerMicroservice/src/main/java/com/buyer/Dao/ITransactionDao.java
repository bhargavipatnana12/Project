package com.buyer.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.buyer.model.Transaction;



public interface ITransactionDao extends JpaRepository<Transaction, Integer>{

}
