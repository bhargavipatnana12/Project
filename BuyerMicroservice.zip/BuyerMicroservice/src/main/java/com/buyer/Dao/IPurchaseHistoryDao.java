package com.buyer.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.buyer.model.PurchaseHistory;



public interface IPurchaseHistoryDao extends JpaRepository<PurchaseHistory, Integer> {

}
