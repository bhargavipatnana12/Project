package com.buyer.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.buyer.model.Buyer;




@Repository
public interface IBuyerDao extends JpaRepository<Buyer, Integer>{

}

	
	


