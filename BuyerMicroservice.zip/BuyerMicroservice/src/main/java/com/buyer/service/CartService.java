package com.buyer.service;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.buyer.Dao.IBuyerDao;
import com.buyer.Dao.ICartDao;
import com.buyer.Dao.IItemDao;
import com.buyer.Dao.IPurchaseHistoryDao;
import com.buyer.Dao.ITransactionDao;
import com.buyer.model.Buyer;
import com.buyer.model.Items;
import com.buyer.model.PurchaseHistory;
import com.buyer.model.ShoppingCart;
import com.buyer.model.Transaction;

@Service
public class CartService implements ICartService {

	@Autowired
	private ICartDao cartDao;
	@Autowired
	private IBuyerDao bdao;

	@Autowired
	private IItemDao itemDao;
	
	@Autowired
	private ITransactionDao transactionDao;
	
	@Autowired
	private IPurchaseHistoryDao purchaseDao;
	
	@Override
	public List<ShoppingCart> getAllCart() {

		return cartDao.findAll();
	}

	@Override
	public Optional<ShoppingCart> getCartById(int bid) {
		// TODO Auto-generated method stub
		return cartDao.findById(bid);
	}

	@Override
	public void deleteById(Integer bId) {
		Optional<ShoppingCart> buyer = cartDao.findById(bId);

		if (buyer.isPresent()) {
			cartDao.deleteById(bId);
		}

	}

	@Override
	public String addCart(int bid, ShoppingCart cItem) {
		Buyer br = bdao.getOne(bid);
		cItem.setBuyer(br);
		// TODO Auto-generated method stub
		System.out.println(cItem);
		cartDao.save(cItem);
		return "item added";

	}

	
	@Override
	public String updateCart(int cid, ShoppingCart sCart) {
		ShoppingCart cartUpdate = cartDao.getOne(cid);
		int quantity = sCart.getQuantity();
		cartUpdate.setQuantity(quantity);
		System.out.println(cartUpdate);
		cartDao.save(cartUpdate);
		return "\"Cart item updated\"";
	}

	@Override
	public void emptyCart(Integer buyerId) {
		cartDao.emptyCart(buyerId);

	}

	@Override
	public List<ShoppingCart> getAllCartItems(Integer buyerId) {
		return cartDao.getAllCartItems(buyerId);
	}

	@Override
	public String checkOut(Transaction transaction, int buyerid) {
		Buyer buyer=bdao.getOne(buyerid);
		System.out.println(buyer);
		transaction.setBuyer(buyer);
		String transactionType1=transaction.getTransactionType();
		transaction.setTransactionType(transactionType1);
		System.out.println(transaction);
		transactionDao.save(transaction);
		
		List<ShoppingCart> sCart=cartDao.getById(buyerid);
		for(int i=0;i<sCart.size();i++)
		{	
			PurchaseHistory pHistory=new PurchaseHistory();
			ShoppingCart scItem=sCart.get(i);
			int noOfItem=scItem.getQuantity();
		//	Date date2=pHistory.getDateTime();
			//pHistory.setDateTime(date2);
			pHistory.setNumberOfItems(noOfItem);
			pHistory.setBuyer(buyer);
			System.out.println(pHistory);
			System.out.println(scItem);
			purchaseDao.save(pHistory);
		}
		
		return null;
	}

	
	

	

}
