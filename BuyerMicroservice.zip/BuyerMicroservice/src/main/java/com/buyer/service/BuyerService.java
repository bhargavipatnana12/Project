package com.buyer.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.buyer.Dao.IBuyerDao;
import com.buyer.model.Buyer;


@Service
public class BuyerService implements IBuyerService {

	
	@Autowired
	private IBuyerDao dao;
	
	
	@Override
	public List<Buyer> getAllPersons() {
		
		return dao.findAll();
	}

	@Override
	public Buyer add(Buyer buyer) {
		
		return dao.save(buyer);
	}

	

	/*
	 * @Override public Optional<ShoppingCartEntity> getbyBuyerId(int pid) {
	 * 
	 * return dao.findById(pid); }
	 */
	

	
}
