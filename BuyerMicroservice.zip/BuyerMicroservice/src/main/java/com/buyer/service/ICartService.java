package com.buyer.service;



import java.util.List;
import java.util.Optional;

import com.buyer.model.ShoppingCart;
import com.buyer.model.Transaction;

public interface ICartService {

	List<ShoppingCart> getAllCart();

	Optional<ShoppingCart> getCartById(int bid);

	

	void deleteById(Integer bId);

	//void deleteAllCart();

	String addCart(int bid, ShoppingCart cItem);
	String updateCart(int cid, ShoppingCart sCart);
	void emptyCart(Integer buyerId);

	List<ShoppingCart> getAllCartItems(Integer buyerId);

	String checkOut(Transaction transaction, int buyerid);
	

	

	

	

//	String addCart(int bid, ShoppingCartEntity scart);

	

	

}
