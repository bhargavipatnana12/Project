


package com.buyer.service;

import java.util.List;
import java.util.Optional;

import com.buyer.model.Buyer;



public interface IBuyerService {

	List<Buyer> getAllPersons();

	Buyer add(Buyer buyer);

	//Optional<ShoppingCartEntity> getbyBuyerId(int pid);
	
	

}
