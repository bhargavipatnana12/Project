package com.buyer.model;

import java.util.List;

import javax.persistence.*;

import org.springframework.beans.factory.annotation.Autowired;


@Entity
@Table(name="cart")
public class ShoppingCart {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int cartId;
	private float price;
	private int quantity;
	
	
	
	  
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public List<Items> getItemsEntity() {
		return itemsEntity;
	}
	public void setItemsEntity(List<Items> itemsEntity) {
		this.itemsEntity = itemsEntity;
	}
	public Buyer getBuyer() {
		return buyer;
	}
	public void setBuyer(Buyer buyer) {
		this.buyer = buyer;
	}
	@OneToMany//(cascade=CascadeType.ALL,mappedBy="shoppingCart")
	  private List<Items> itemsEntity;
	    
	  @ManyToOne
	  private Buyer buyer;
	 
	 
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	
	
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	
	public ShoppingCart() {
		
		// TODO Auto-generated constructor stub
	}
	
	public ShoppingCart(int cartId, float price, int quantity) {
		super();
		this.cartId = cartId;
		this.price = price;
		
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "ShoppingCartEntity [cartId=" + cartId + ", price=" + price + ", quantity=" + quantity + "]";
	}
	
	
	
	
	
	
	

}