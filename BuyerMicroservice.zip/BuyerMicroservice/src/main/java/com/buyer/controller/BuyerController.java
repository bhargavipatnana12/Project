package com.buyer.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.buyer.model.Buyer;
import com.buyer.service.IBuyerService;





@RestController
public class BuyerController {
	
	@Autowired
	private IBuyerService service;
	
	@GetMapping("/getAll")
	public List<Buyer> getAll(){
		
		return service.getAllPersons();
	}
	
	
	@RequestMapping(value="/addBuyer", method= RequestMethod.POST, produces="application/json")
	public Buyer addBuyer(@RequestBody Buyer person) {
		
		return service.add(person);
	}
	
	
	
	

}

