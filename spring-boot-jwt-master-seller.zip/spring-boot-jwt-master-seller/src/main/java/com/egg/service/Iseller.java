package com.egg.service;

import java.util.List;

import org.springframework.stereotype.Service;


import com.egg.model.Items;
import com.egg.model.Seller;


@Service
public interface Iseller {
	
	
	//Seller Service
	
	List<Seller> getAll();
	Seller addSeller(Seller seller);
	Seller getSeller(int id);
	Seller updateSeller(Seller seller,int id);
	Seller findOne(String username);
	
	
	
	// Items Service
	
	List<Items> getAllItems();
	Items addItems(Items items);
	Items getProduct(int id);
	Items updateItems(Items items,int id);
	void deleteById(Integer itemId);
	List<Items> getByAllitemName(String itemname);

}
