package com.egg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.egg.model.Items;



@Repository
public interface ItemsDao extends JpaRepository<Items, Integer> {
	@Query(value="FROM Items WHERE lower(itemName) LIKE %:itemName%")
	List<Items> getByitemName(@Param("itemName")String name);


}
