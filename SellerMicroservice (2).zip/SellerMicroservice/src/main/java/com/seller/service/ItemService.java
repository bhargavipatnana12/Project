package com.seller.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seller.Dao.IItemDao;
import com.seller.Dao.ISellerDao;
import com.seller.model.Items;
import com.seller.model.Seller;




@Service
public class ItemService implements IItemService {
	
	@Autowired
	private IItemDao itemDao;
	
	@Autowired
	private ISellerDao sDao;

	@Override
	public String addItem(int sid, Items item) {
		Seller i=sDao.getOne(sid);
		item.setSellerid(i);
		System.out.println(item);
		itemDao.save(item);
		
		return "item added";
	}

	@Override
	public void deleteBySeller(Integer sId, Integer pId) {
		itemDao.deleteItem(sId,pId);
		
	}

	@Override
	public List<Items> viewItem(Integer sellerId) {
		return itemDao.viewItem(sellerId);
		
	}

	@Override
	public String updateItem(int sid, int pid, Items item) {
		
		Items updateItem1=itemDao.getItemBy(sid,pid);
		System.out.println(updateItem1);
		//System.out.println(item);
		float price1=item.getPrice();
		int stockNumber1=item.getStockNumber();
		updateItem1.setPrice(price1);
		updateItem1.setStockNumber(stockNumber1);
		System.out.println(updateItem1);

		itemDao.save(updateItem1);
				return "updated";
	}

	
	
	
	
	

}
