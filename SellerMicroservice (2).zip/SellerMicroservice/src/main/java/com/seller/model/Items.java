package com.seller.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="items")
public class Items {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int itemIid;
	private float price;

	private String itemName;
	private String description;
	private int stockNumber;
	private String remarks;
	@ManyToOne
	@JoinColumn(name="sellerid")
	private Seller sellerid;
	public int getItemIid() {
		return itemIid;
	}
	public void setItemIid(int itemIid) {
		this.itemIid = itemIid;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStockNumber() {
		return stockNumber;
	}
	public void setStockNumber(int stockNumber) {
		this.stockNumber = stockNumber;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Seller getSellerid() {
		return sellerid;
	}
	public void setSellerid(Seller sellerid) {
		this.sellerid = sellerid;
	}
	public Items(int itemIid, float price, String itemName, String description, int stockNumber, String remarks,
			Seller sellerid) {
		super();
		this.itemIid = itemIid;
		this.price = price;
		this.itemName = itemName;
		this.description = description;
		this.stockNumber = stockNumber;
		this.remarks = remarks;
		this.sellerid = sellerid;
	}
	@Override
	public String toString() {
		return "Items [itemIid=" + itemIid + ", price=" + price + ", itemName=" + itemName + ", description="
				+ description + ", stockNumber=" + stockNumber + ", remarks=" + remarks + ", sellerid=" + sellerid
				+ "]";
	}
	public Items() {
		
		// TODO Auto-generated constructor stub
	}
	
}
