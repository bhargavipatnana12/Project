package com.seller.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="sub_category")

public class Sub_Category {
   
	@Id

   @GeneratedValue( strategy = GenerationType.IDENTITY)
	private int subCategoryId;
	private String subCategoryName;
	
	private String briefDetails;
	@ManyToOne
	@JoinColumn(name="categoryId")
	private Category categoryId;
	public int getSubCategoryId() {
		return subCategoryId;
	}
	public void setSubCategoryId(int subCategoryId) {
		this.subCategoryId = subCategoryId;
	}
	public String getSubCategoryName() {
		return subCategoryName;
	}
	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}
	public String getBriefDetails() {
		return briefDetails;
	}
	public void setBriefDetails(String briefDetails) {
		this.briefDetails = briefDetails;
	}
	public Category getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(Category categoryId) {
		this.categoryId = categoryId;
	}
	@Override
	public String toString() {
		return "Sub_Category [subCategoryId=" + subCategoryId + ", subCategoryName=" + subCategoryName
				+ ", briefDetails=" + briefDetails + ", categoryId=" + categoryId + "]";
	}
	public Sub_Category(int subCategoryId, String subCategoryName, String briefDetails, Category categoryId) {
		super();
		this.subCategoryId = subCategoryId;
		this.subCategoryName = subCategoryName;
		this.briefDetails = briefDetails;
		this.categoryId = categoryId;
	}
	public Sub_Category() {
		// TODO Ausuperto-generated constructor stub
	}
	
	
}
